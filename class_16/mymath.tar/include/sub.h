#pragma once
int sub(int x,int y);
